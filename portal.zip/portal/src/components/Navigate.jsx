import React, { Component } from 'react'

export class Navigate extends Component {
    render() {
        return (
            <div>
                HI
            </div>
        )
    }
}

export default Navigate
