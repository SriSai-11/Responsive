import React, { Component } from 'react'
import Slider from './Slider';
import Industry from './Industry';
import Technology from './Technology';

export class SellContent extends Component {
    render() {
        return (
            <div>
                <Slider/>
                <Industry/>
                <Technology/>
            </div>
        )
    }
}

export default SellContent
