import React, { Component } from 'react'
import { Tabs, Tab, TabPanel, TabList } from "react-web-tabs";
import { Typography } from '@material-ui/core'

import './styles.css'
export class DigitalContent extends Component {
  render() {
    return (
        
      <div className="App" >
        <div style={{backgroundImage: `url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaN1HK9ttAMwgvVpmzv4ImAME-M4dLBfAacw&usqp=CAU")` ,backgroundRepeat: "no-repeat",backgroundSize: "cover",width:'100%',height:'280px'}}>
               <Typography variant="h3" style={style1} >Accelerate Your Digital Quotient</Typography>
        </div>
        <div style={{backgroundColor: '#F4F1F4',height:'600px'}}>
      <Tabs defaultTab="vertical-tab-one" vertical >
        <TabList >
          <Tab tabFor="vertical-tab-one"   style={{textAlign:'left'}}>About GTO</Tab>
          <Tab tabFor="vertical-tab-two"   style={{textAlign:'left'}}>How to upgrade yourself?</Tab>
          <Tab tabFor="vertical-tab-three" style={{textAlign:'left'}}>Who to reach out to?</Tab>
          <Tab tabFor="vertical-tab-four"  style={{textAlign:'left'}}>How else to be involved?</Tab>
          <Tab tabFor="vertical-tab-five"  style={{textAlign:'left'}}>Fun Digital Quotient test</Tab>

        </TabList>
        <TabPanel tabId="vertical-tab-one" className="tablist">
          <p>Tab 1 content</p>
        </TabPanel>
        <TabPanel tabId="vertical-tab-two"  className="tablist">
          <p>Tab 2 content</p>
        </TabPanel>
        <TabPanel tabId="vertical-tab-three"  className="tablist">
          <p>Tab 3 content</p>
        </TabPanel>
        <TabPanel tabId="vertical-tab-four"  className="tablist">
          <p>Tab 4 content</p>
        </TabPanel>
        <TabPanel tabId="vertical-tab-five"  className="tablist">
          <p>Tab 5 content</p>
        </TabPanel>
      </Tabs>
      </div>
    </div>
    )
  }
}


// const style={
//   textAlign : 'justify'
// }

const style1 = {
  paddingTop: 100,
  color: 'white'
}


export default DigitalContent
