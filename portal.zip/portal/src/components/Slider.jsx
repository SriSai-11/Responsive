import React, { Component } from 'react'
import Carousel from 'react-bootstrap/Carousel'
import 'bootstrap/dist/css/bootstrap.min.css'
import './styles.css'
export class slider extends Component {
    render() {
        return (
            <div>
                <Carousel>
                <Carousel.Item>
                    <img
                    className="d-block w-100"
                    src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEA8QDw8PDw8PDw0PDw8PDQ8NDQ8NFREWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGBAQFy0dHR0tLS0tLSstLS0tLS0tLS0tKy0tLS0rLSstLS0tLSsrLS0tKy0tLS0rKy0tLS0tLS0rLf/AABEIAI4BYwMBIgACEQEDEQH/xAAaAAADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QANBAAAgIBAQYDBAoDAQAAAAAAAAECEQMhBBIxQVFhcYGREyKxwQUUMkJScqHh8PEzYtGS/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/8QAHxEBAQEBAAICAwEAAAAAAAAAAAERAhIhAzETQVEi/9oADAMBAAIRAxEAPwD5YCbGe16tXY7IsdhKux2RYWRirsVk2Kw5dKbJbJbJcg49G2RJg2S15FkebtnORzzZtOupjS7m5y8Py9T6QmaJUKEOf8sbRuRxpORLYMRVkS2Q2ORm2R0kJshjbJI6SAAGAgAAAAAAAAADXZ1LeW5x+XfsTjg5OkrZ62y4FBdW+L+RnvqSNSar2TpcL51or7EOPU6LKjHqefVvEv05t0Nw6nCP9ai3F39ETVnxubcCUToqPVjjii136WrGr4OJsaxXq+HQ1ljphY8k8R4GOfZN5e7SduTXJtnQtNWUr/dk8rPbU515WPZmppSVVq3yfQ7czekfN+J0ez66vXmcuefTt5i93qunjJzkTurqBlqBdZ8XpWFk2FnZ9jVWOzOwsGtLDeIQxjFqrAlyJchjl1VMN0V1x9DOeUuPP100k6MZyIlkMZ5TUjyfJ1hzkETND3jo8d9tU9PMlyKi0ou+pk5oJ4iRDY94mQakEmZSLbIYbjNgOhGXQDEAAAAEAAAAAABpizSj9l1fZM7dl2icvuprm9YmGx7Lvu39lfr2PSSSVJUlwo5d2NSKc+mnxEu5JUWcmt1oiZTKjGzPJHUy2TZMmTKRPj6cyoqORvR+T+RcI+RHH5I6MUbr+akqz2UI82UtRz1dD0SbfBIxXSRGSWjS46WcOaOpvjlo2+Mm2S1zNZhrNRA1oCKuwskKPU9/kpsETFMpsYl6OxORDkLeLjF6XY7ozsznMuOXXS55DGUzOczGUy483feNJ5CEyNSompHl6utGyWyWxWViRpGYpGTZSmF8Q2CYpCiFw5MmxskLDYh2IigAoAEAwIEAAAG+yYN+Vclq/DoZQi20lxZ7GDEoRpeb6sz31kWRpSWi4LgSxks4NWguBA4MEbqKJlj6FQXoWzFdY5tzpT72Zbj6G0sdaswyFjNWl4nVF0kjjwzfVnfFujHVb4jNHJt2bVQXa9HxfA7p5FFNvgjzYVKW9J6yeiT1t/AvE/bbaKvhy+AOJfs0uFm0afiRHPQjpePsAHFvDTM94qD5nsx382yYpUZOfMzUxiXs5SoSkRmfMy9oWRz6+RvKZhPIQ52I3jz9fKddfQreIQmyuF2td8LMkykEw7FYMgGKddCXFABGiVjAABk0UACoAAikAxMBAAEAAFRjbSXFtIDu+j8NLffF6Lw6nW2EY0klwSobPPbtaKxNgxBBZcV19BKP9lErXMbxZSMIzo139PH+f9OddoMvA5GjqjK3/NRxxK7Xo+RNXNYwxpLXRLVsMm3Y1om3y0Wl+LF9IZKSguer8DzOMu0dX+Y3zxs2r9OjPlc3rolyHsq9+Pj8iUhwdNPo0zdmTFl16TgZtVwOhozmlxZ5yo9sxGEpuwNYx5Rx7xTnyOdT5i3j34535W2TJoY+0ImyEMZ87W8p2jJDiNKisWmSDYFRRI2JIENDGojoJqWSWxUQiQGIKAAQUADEQMAABAAEAIYgA6NhjeSPa3+hznb9Gx1k+yXq/wBidfSx6JLBsKPOtKh0CKoEhFJBRSRm105iaKn8NBpajrr/AGY10xnCNmm0Z9yNvjyXOzDNtaiqjrL9E+5wSk5O27fc3zzv219DLkb1buTYoRr+cyN7V83wS+ZpFWdUjRMbMuBcZCUseps096K6rRmeeXLocK2r2evXRrqdGOW/G4u0+Zx64y6lrGXEDV4gLrn7eSh2SM9rgGhKI91lJUDTjGhMZLKgAQ0gKSHYWTZEOwEAAIdisKBABFAhiCgAABAAEAAgAYgABpHq7Jh3Y0+L1fZ9DygTa4OvDQz1NWPboZ4yzT/FL/0y47VNfefnT+Jj8dXY9ehnlLbsnVPyQfXsnVeiJ+OrseshtpatpeLpHiz2zI/vNeFIwlNvi2/F2T8f9anb2p7fjjz3n/qr/U5J7ZLIq+zHpzfizz5R9TogqSQ8JG+era0KQoobDoGXFURBGhUBlPTU0OLNkt9uQntOr4xWWe9XY9D6LfuP83yR5SZ2/Rc/ekuqvzT/AHY7n+XKXevb0mgBgefW8eGikSB73mqxCTBlQAxDoASKAAEFAFgFiCxEAACCmIBBTAQAAAIgYgAAAAAAAAAAAAAAAAAAEy8UeZCVs3apGK6cz9ohG3ZvFE446GqMV14noCYMcERtcdBsQNjUxGSdI8+ztyHFJU2jXLn8hnT9H/5I+EvgcpcJtNNOmuDNWbMc56r3rGeN9cyfifov+AcPxV084zGIZ63ADQhoqGkMLFYZAWKxEXDsQCC4YCAKBBYAAAIgYgAAAAAAAAAAAAAAAAAAAAAABjEwrTDHmXPikOHAmGrs5un6z+tYjGiJyoy7G2UmYplpkGtiZKY7Cs8ro55u+zX6mkpbz7IicTpJ6ebvrazR2Z9gkn7nvLpomjnxr30v9l8T25ox31ZY1zNjxfq8/wAEvRge0pAZ/Lf414R4YxAelwUAhhDsQAACAAoAQAAAIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZIwYVpv6MrC1xOcRixuV1Tzrlr8DJSMkykyY3OtaplJmSZSZlvWqkZ58nJeZMp0ZFkY76/SoyobmSBtyxrs6vJD80fie7JHibJ/kh4nuHD5ft14+mQF0Bzaf/9k="
                    alt="First slide"
                    class="img-fluid"
                    />
                    <Carousel.Caption>
                    <h3>Engineering SaaS Cloudification</h3>
                    <p>30% Reduction in OPEX</p>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                    className="d-block w-100"
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTaTKh-m2ZRBruvwPRdKJL_-jzoe6dKUVQ2uA&usqp=CAU" 
                    alt="Second slide"
                    class="img-fluid"
                    />

                    <Carousel.Caption>
                    <h3>second slide label</h3>
                    <p>content</p>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                    className="d-block w-100"
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJVPsju8Q6xuvfWtICVCKPgc8mW86Dmk1j9Q&usqp=CAU"
                    alt="Third slide"
                    class="img-fluid"
                    />

                    <Carousel.Caption>
                    <h3>Third slide label</h3>
                    <p>Content</p>
                    </Carousel.Caption>
                </Carousel.Item>
                </Carousel>
                            </div>
                        )
                    }
                }


export default slider
