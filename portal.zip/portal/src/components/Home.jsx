import React from 'react'
import { Cards } from './Cards'
import Title from './Title'

function Home() {
    return (
        <div>
            <Title/>
            <Cards/>
        </div>
    )
}

export default Home
