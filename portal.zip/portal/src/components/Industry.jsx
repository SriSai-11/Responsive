import React, { Component } from 'react'
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
// import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
// import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
// import Divider from '@material-ui/core/Divider';
import Box from "@material-ui/core/Box";
import Container from "@material-ui/core/Container";
import { Grid } from '@material-ui/core';
import Strapi from 'strapi-sdk-javascript/build/main';
// import Title from './Title';

// import { Carousel } from "react-responsive-carousel";
// import InfiniteCarousel from 'react-leaf-carousel';

const strapi = new Strapi('http://localhost:1337');
const styles = theme => ({
  container: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 30,
    
  },
  
  card: {
    maxWidth: 225,
  },

  
  media: {
    height: '300px',
    width:'auto'
  },

  

});
    

export class Industry extends Component {
  constructor(props){
    super(props)
      this.state = {
        images:[],
        tech:[],
        // userExperinceClick : false, 
       'User Experience':false,
        Mobility:false,


    }
    
  }

  async componentDidMount() {
    try {
      const images = await strapi.getEntries('success-stories')
      const tech = await strapi.getEntries('technologies')
      console.log(images)
      console.log(tech)
      this.setState({ images });
      this.setState({ tech });
    } 
    catch(err) {
     alert(err);
    }
   }

   myClick=(e)=>{
     console.log("AAAAAA",e.target.title)
    // alert(e.target.title)
    // if(e.target.title.length > 0)
    // this.setState({[e.target.title]:true})
   }

    render() {
      const { classes } = this.props;
    // console.log("SSSSSSSSSSSSSSSSSSSSs",this.state)

        return (
            <div style={{backgroundColor: '#9E7BED',height:'525px',paddingTop:'20px'}}>           
              <Typography variant="h3" style={style}>Technology</Typography>
                  <Container style={{display: 'flex',justifyContent: 'center',paddingBottom: '20px'}}>
                    
                    <Grid container spacing={4} xs={8} >
                    {this.state.images.map((imagesData,index) => (
                      
                      <Grid item md={4} >
                      {/* <Box my={4}>   */}
                  
                        <Card className={classes.card} >
                          <CardActionArea>
                          {/* {this.state.images.map(post => ( */}
                            <CardMedia 
                              className={classes.media}
                              style={{
                                height: "5px",
                                marginLeft: "60px",
                                paddingLeft: "40px",
                                paddingTop: "70px",
                                marginTop: "40px",
                                width: "100px",
                                backgroundRepeat: 'no-repeat'
                              }}
                              alt=""
                              // image={`http://localhost:1337${imagesData.featuredimage}`}
                              image={`http://localhost:1337${imagesData.image[0].url}`}
                            />
                              {/* ))}   */}
                           
                            <CardContent style={style1}>
                              <Typography gutterBottom variant="h5" component="h2" style={{marginTop:'20px',fontSize:'15px',fontColor:'black',fontWeight:'bold'}}>
                               {imagesData.name}
                              </Typography>
                              <Typography variant="body2" color="textSecondary" component="p">
                                {imagesData.description}
                              </Typography>
                            </CardContent>
                          </CardActionArea>
                        </Card>
                      {/* </Box> */}
                      
                      </Grid>

                      
        
                    ))} 


              </Grid>
      </Container>
      {this.state['User Experience'] ? <h1>hi Mobility</h1> : null}
      

      <Container style={{display: 'flex', justifyContent: 'center', paddingBottom:'600px'}}>
                    <Grid container spacing={4} xs={10} >
                    {this.state.tech.map((techno,index) => (
                      
                      // <Grid item md={3} name={techno.name} value={index}  >
                      <Box my={4}>   
                  {/* {(e) => this.deleteRow(id, e) */}
                        <Card className={classes.card}  onClick={(e) => this.myClick(e)}>
                          <CardActionArea>
                          {/* {this.state.tech.map(post => ( */}
                            <CardMedia 
                              // className={classes.media}
                              //948 709 879
                              style={{
                                height: "1px",
                                marginLeft: "70px",
                                paddingLeft: "40px",
                                paddingTop: "70px",
                                marginTop: "30px",
                                width: "70px"
                              }}
                              alt=""
                              // image={`http://localhost:1337${imagesData.featuredimage}`}
                              image={`http://localhost:1337${techno.image[0].url}`}
                              title={techno.name}
                            />
                             {/* ))}  */}
                           
                            <CardContent style={style1}>
                              <Typography gutterBottom variant="h5" name={techno.name} component="h2" style={{marginTop:'20px',fontSize:'15px',fontColor:'black',fontWeight:'bold'}}>
                               {techno.name}
                              </Typography>
                            </CardContent>
                          </CardActionArea>
                        </Card>
                      </Box> 
                      
                      /* </Grid> */

                      
        
                    ))} 


              </Grid>
      </Container>
            </div>
            

        )
    }
}


const style = {
  paddingBottom: '20px',
  fontSize:30,
  color: 'white'
}

// const button = {
//   marginLeft:150
// }

const style1={
  height:'100px',
}

// const style2 = {
//   marginLeft:'10px'
// }
export default withStyles(styles, { withTheme: true })(Industry)


