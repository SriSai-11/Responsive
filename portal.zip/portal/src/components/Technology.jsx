import React, { Component } from 'react'
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
// import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
// import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
// import Divider from '@material-ui/core/Divider';
// import Box from "@material-ui/core/Box";
import Container from "@material-ui/core/Container";
import { Grid } from '@material-ui/core';
import Strapi from 'strapi-sdk-javascript/build/main';

// import { Carousel } from "react-responsive-carousel";
// import InfiniteCarousel from 'react-leaf-carousel';

const strapi = new Strapi('http://localhost:1337');
const styles = theme => ({
  container: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 30,
    
  },
  
  card: {
    maxWidth: 300,
  },

  
  media: {
    height: 20,
  },

  

});
    

export class Technology extends Component {
  constructor(props){
    super(props)
      this.state = {
        images:[],
    }
  }

  async componentDidMount() {
    try {
      const images = await strapi.getEntries('industries')
      console.log(images)
      this.setState({ images });
    } 
    catch(err) {
     alert(err);
    }
   }
  
    render() {
      const { classes } = this.props;
        return (
            <div style={{backgroundColor: '#F4F1F4',paddingTop:'10px'}}>           
              <Typography variant="h3" style={style}>Industries</Typography>
                  <Container style={{display: 'flex',justifyContent: 'center', paddingBottom:'30px'}}>
                    
                    <Grid container spacing={2} xs={8} >
                    {this.state.images.map((imagesData,index) => (
                      
                      <Grid item md={4} >
                      {/* <Box my={4}>   */}
                  
                        <Card className={classes.card} >
                          <CardActionArea>
                          {/* {this.state.images.map(post => ( */}
                            <CardMedia 
                              // className={classes.media}
                              style={{
                                height: "30px",
                                marginLeft: "80px",
                                paddingLeft: "40px",
                                paddingTop: "60px",
                                marginTop: "40px",
                                width: "80px"
                              }}
                              alt=""
                              // image={`http://localhost:1337${imagesData.featuredimage}`}
                              image={`http://localhost:1337${imagesData.image[0].url}`}
                            />
                             
                           
                            <CardContent style={style1}>
                              <Typography gutterBottom variant="h5" component="h2" style={{marginTop:'20px',fontSize:'15px',fontColor:'black',fontWeight:'bold'}}>
                               {imagesData.name}
                              </Typography>
                              <Typography variant="body2" color="textSecondary" component="p">
                                {imagesData.description}
                              </Typography>
                            </CardContent>
                          </CardActionArea>
                        </Card>
                     
                      
                      </Grid>

                      
        
                    ))} 


              </Grid>
      </Container>
            </div>
            

        )
    }
}


const style = {
  paddingBottom: '15px',
  fontSize:30,
}

// const button = {
//   marginLeft:150
// }

const style1={
  height:'100px',
}

// const style2 = {
//   marginLeft:'10px'
// }
export default withStyles(styles, { withTheme: true })(Technology)


